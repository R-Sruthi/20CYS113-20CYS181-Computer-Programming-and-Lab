# PRTOGRAM TO CONVERT FAHRENHEIT TO CELSIOUS
# Declareing the variable for celsious
print("Enter the F value to convert")
f = int(input())

# Taking the value of celsious to convert
# Declaring variable f for fahrenheit
c = float((f - 32) * 5) / 9

# using the formula to convert
print("The value of C is")
print(c)
