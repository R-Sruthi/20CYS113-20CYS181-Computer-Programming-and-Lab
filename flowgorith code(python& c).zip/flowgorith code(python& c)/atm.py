print("Enter your account number")
accno = input()
print("Enter your pin no")
pin = int(input())
print("Enter your bank balance")
balance = int(input())
minbal = 500

# we are using if condition to check if the balance in the account is more thanm the minimum balance to withdraw money
print("enter the amounbt you wan tto withdraw")
amount = int(input())
if balance - amount < minbal:
    print("if the transcation is processed then your balance will become less than the min balnce. Do you want to continue?(y/n)")
    ans = input()
    if ans == "y":
        print("Enter your pin number to proceeed with the transcation")
        
        # Checking if the pin number entered is correct
        pinno = int(input())
        if pinno == pin:
            print("your transation is being processed. please wait..")
            print("Transaction successfull")
            print("your current bank balance")
            balance2 = balance - amount
            print(balance2)
            print("Thank you for choosing our bank.Have a nice day")
        else:
            print("Transaction Failed. Please enter the correct pin number")
else:
    pinno = int(input())
    if pinno == pin:
        print("your transation is being processed. please wait..")
        print("Transaction successfull")
        print("your current bank balance")
        balance2 = balance - amount
        print(balance2)
        print("Thank you for choosing our bank.Have a nice day")
    else:
        print("Transaction Failed. Please enter the correct pin number")
