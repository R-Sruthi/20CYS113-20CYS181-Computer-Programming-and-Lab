# initialising sum to 0
sum = 0
print("Enter the value till which you want the sum of")
n = int(input())

# initialising i to 1
i = 1
while i <= n:
    sum = sum + i
    
    # incrememnting i by 1 for each iteratrion
    i = i + 1
print("sum of the n numbers is")
print(sum)
