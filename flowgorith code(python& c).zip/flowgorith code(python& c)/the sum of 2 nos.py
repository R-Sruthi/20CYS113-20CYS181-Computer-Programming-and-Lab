sum = 0
print("enter the how many nos")
n = int(input())
i = 0
while i < n:
    print("enter no to add")
    no = int(input())
    sum = sum + no
    i = i + 1
print(sum)
