# PRTOGRAM TO CONVERT CELSIOUS TO FAHRENHEIT
# Declareing the variable for celsious
print("Enter the c value to convert")
c = int(input())

# Taking the value of celsious to convert
# Declaring variable f for fahrenheit
f = float(9) / 5 * c + 32

# using the formula to convert
print("The value of f is")
print(f)
