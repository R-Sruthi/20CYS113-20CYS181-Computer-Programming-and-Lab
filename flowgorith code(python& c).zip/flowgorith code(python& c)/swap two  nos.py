# "PROGRAM FOR SWAPPING 2 NOS"
print("enter variable a")

# taking input of a
a = int(input())
print("enter variable b")

# taking input of b
b = int(input())
a = a + b
b = a - b
a = a - b
print("a=")
print(a)
print("b=")
print(b)
